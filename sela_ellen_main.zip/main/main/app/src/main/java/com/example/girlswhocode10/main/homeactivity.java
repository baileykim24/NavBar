package com.example.girlswhocode10.main;

import android.app.Activity;
import android.content.Intent;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.girlswhocode10.main.utils.BottomNavigationViewHelper;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class homeactivity extends AppCompatActivity {

    private static final String TAG = "homeactivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Button newButton = (Button) findViewById(R.id.quotes_button);
        newButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent StartIntent = new Intent(getApplicationContext(), activity1.class);
                startActivity(StartIntent);
            }
        });

        Button StoriesButton = (Button) findViewById(R.id.stories_button);
        StoriesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent NewIntent = new Intent(getApplicationContext(), activity2.class);
                startActivity(NewIntent);
            }
        });

        Button VideosButton = (Button) findViewById(R.id.videos_button);
        VideosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent VideoScreen = new Intent(getApplicationContext(), activity3.class);
                startActivity(VideoScreen);


            }
        });

        ImageButton profilebutton = (ImageButton) findViewById(R.id.profilebutton);
        profilebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent profilescreen = new Intent(getApplicationContext(), profile.class);
                startActivity(profilescreen);


            }
        });

        ImageButton forumbutton = (ImageButton) findViewById(R.id.forumbutton);
        forumbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent forumscreen = new Intent(getApplicationContext(), forum.class);
                startActivity(forumscreen);


            }
        });

        ImageButton moodbutton = (ImageButton) findViewById(R.id.imageButton3);
        moodbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moodscreen = new Intent(getApplicationContext(), moodtracker.class);
                startActivity(moodscreen);


            }
        });
        Log.d(TAG,"onCreate: starting:");

        setupBottomNavigationView();
    }


    /**
     * BottomNavigationView setup
     */
    private void setupBottomNavigationView(){
        Log.d(TAG,"setupBottomNavigatonView: setting up BottomNavigationView");
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setupBottomNavigationView(bottomNavigationViewEx);


    }



}
