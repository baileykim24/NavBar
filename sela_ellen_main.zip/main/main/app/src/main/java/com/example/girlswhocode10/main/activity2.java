package com.example.girlswhocode10.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.girlswhocode10.main.utils.BottomNavigationViewHelper;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class activity2 extends AppCompatActivity {

    private static final String TAG = "homeactivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);

        Button readMore1 = (Button)findViewById(R.id.read_more_button_1);
        readMore1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String HappyNews = "https://www.boredpanda.com/animals-good-news-faith-in-humanity-restored-2016/";
                Uri webaddress = Uri.parse(HappyNews);

                Intent GoToHappyNews = new Intent(Intent.ACTION_VIEW, webaddress);
                if (GoToHappyNews.resolveActivity(getPackageManager()) != null){
                    startActivity(GoToHappyNews);
                }
            }
        });

        Button readMore2 = (Button)findViewById(R.id.read_more_button_2);
        readMore2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String HappyNews2 = "https://www.huffingtonpost.com/entry/strangers-helping-someone-they-dont-know_us_5ae385fde4b055fd7fcbd035";
                Uri webaddress2 = Uri.parse(HappyNews2);

                Intent GoToHappyNews2 = new Intent(Intent.ACTION_VIEW, webaddress2);
                if (GoToHappyNews2.resolveActivity(getPackageManager()) != null) {
                    startActivity(GoToHappyNews2);
                }
            }
        });

        Button readMore3 = (Button)findViewById(R.id.read_more_button_3);
        readMore3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String HappyNews3 = "https://www.huffingtonpost.com/entry/national-puppy-day-2018-photographs_us_5ab4d34ce4b054d118e1c10f";
                Uri webaddress3 = Uri.parse(HappyNews3);

                Intent GoToHappyNews3 = new Intent(Intent.ACTION_VIEW, webaddress3);
                if (GoToHappyNews3.resolveActivity(getPackageManager()) !=null) {
                    startActivity(GoToHappyNews3);
                }
            }
        });

        Log.d(TAG,"onCreate: starting:");

        setupBottomNavigationView();
    }


    /**
     * BottomNavigationView setup
     */
    private void setupBottomNavigationView(){
        Log.d(TAG,"setupBottomNavigatonView: setting up BottomNavigationView");
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setupBottomNavigationView(bottomNavigationViewEx);


    }



}
